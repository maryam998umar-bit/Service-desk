import test from 'node:test';
import assert from 'node:assert/strict';
import { computeDue, slaState, SLA_HOURS } from '../src/sla.js';
import { canTransition, requesterCanTransition, canViewTicket } from '../src/workflow.js';

const T0 = new Date('2026-01-05T09:00:00Z');
const at = h => new Date(T0.getTime() + h * 3600_000);
const ticket = (priority, extra = {}) => ({ created_at: T0, sla_due_at: computeDue(T0, priority), resolved_at: null, ...extra });

test('SLA due date follows the priority table', () => {
  for (const [p, h] of Object.entries(SLA_HOURS)) assert.equal(computeDue(T0, p).getTime(), at(h).getTime());
});
test('unknown priority is rejected', () => assert.throws(() => computeDue(T0, 'urgent')));

test('open ticket: on_track early, at_risk in last 25%, breached after due', () => {
  const t = ticket('high'); // 8h window
  assert.equal(slaState(t, at(1)), 'on_track');
  assert.equal(slaState(t, at(5.9)), 'on_track');
  assert.equal(slaState(t, at(6.5)), 'at_risk');
  assert.equal(slaState(t, at(8)), 'at_risk'); // exactly at deadline is not yet breached
  assert.equal(slaState(t, at(8.01)), 'breached');
});
test('resolved ticket is judged on resolution time, not on now', () => {
  assert.equal(slaState(ticket('high', { resolved_at: at(7) }), at(500)), 'met');
  assert.equal(slaState(ticket('high', { resolved_at: at(9) }), at(500)), 'breached');
  assert.equal(slaState(ticket('high', { resolved_at: at(8) }), at(500)), 'met'); // boundary
});
test('raising priority shortens the deadline from the original creation time', () => {
  assert.ok(computeDue(T0, 'critical') < computeDue(T0, 'low'));
});

test('agent status transitions', () => {
  assert.ok(canTransition('open', 'in_progress'));
  assert.ok(canTransition('on_hold', 'in_progress'));
  assert.ok(canTransition('resolved', 'closed'));
  assert.ok(!canTransition('open', 'closed'));
  assert.ok(!canTransition('closed', 'open'));
  assert.ok(!canTransition('on_hold', 'resolved'));
});
test('requester can only close or reopen a resolved request', () => {
  assert.ok(requesterCanTransition('resolved', 'closed'));
  assert.ok(requesterCanTransition('resolved', 'in_progress'));
  assert.ok(!requesterCanTransition('open', 'closed'));
  assert.ok(!requesterCanTransition('open', 'resolved'));
  assert.ok(!requesterCanTransition('in_progress', 'resolved'));
});
test('ticket visibility by role', () => {
  const t = { requester_id: 7, category: 'IT' };
  assert.ok(canViewTicket({ id: 7, role: 'employee' }, t));
  assert.ok(!canViewTicket({ id: 8, role: 'employee' }, t));
  assert.ok(canViewTicket({ id: 1, role: 'agent', department: 'IT' }, t));
  assert.ok(!canViewTicket({ id: 1, role: 'agent', department: 'HR' }, t));
  assert.ok(canViewTicket({ id: 2, role: 'admin' }, t));
});
