export const STATUSES = ['open', 'in_progress', 'on_hold', 'resolved', 'closed'];
export const CATEGORIES = ['IT', 'HR', 'FACILITY'];

const NEXT = {
  open: ['in_progress', 'on_hold', 'resolved'],
  in_progress: ['open', 'on_hold', 'resolved'],
  on_hold: ['in_progress'],
  resolved: ['closed', 'in_progress'], // in_progress = reopen
  closed: [],
};

export const canTransition = (from, to) => (NEXT[from] || []).includes(to);
// Requesters may only confirm (close) or reopen once an agent has resolved the ticket.
export const requesterCanTransition = (from, to) =>
  from === 'resolved' && (to === 'closed' || to === 'in_progress');

export function canViewTicket(user, ticket) {
  if (user.role === 'admin') return true;
  if (user.role === 'agent') return ticket.category === user.department;
  return ticket.requester_id === user.id;
}
