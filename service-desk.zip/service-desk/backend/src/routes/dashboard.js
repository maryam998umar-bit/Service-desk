import { Router } from 'express';
import { query } from '../db.js';
import { authenticate, requireRole } from '../auth.js';
import { wrap } from '../http.js';

const r = Router();
r.use(authenticate, requireRole('agent', 'admin'));

r.get('/', wrap(async (req, res) => {
  // Agents see their department only; admins see everything.
  const scope = req.user.role === 'agent' ? 'WHERE category = $1' : 'WHERE $1::text IS NULL OR TRUE';
  const p = [req.user.role === 'agent' ? req.user.department : null];

  const [byStatus, byCategory, sla, workload] = await Promise.all([
    query(`SELECT status, count(*)::int AS n FROM tickets ${scope} GROUP BY status`, p),
    query(`SELECT category, count(*)::int AS n FROM tickets ${scope} GROUP BY category ORDER BY category`, p),
    query(`SELECT
        count(*) FILTER (WHERE resolved_at IS NULL AND sla_due_at < now())::int AS open_breached,
        count(*) FILTER (WHERE resolved_at IS NULL AND sla_due_at >= now()
                         AND (sla_due_at - now()) < 0.25 * (sla_due_at - created_at))::int AS at_risk,
        count(*) FILTER (WHERE resolved_at IS NOT NULL)::int AS resolved_total,
        count(*) FILTER (WHERE resolved_at IS NOT NULL AND resolved_at <= sla_due_at)::int AS resolved_in_sla,
        round((avg(extract(epoch FROM (resolved_at - created_at)) / 3600)
               FILTER (WHERE resolved_at IS NOT NULL))::numeric, 1) AS avg_resolution_hours
      FROM tickets ${scope}`, p),
    query(`SELECT u.name, count(t.id)::int AS active_tickets
           FROM users u LEFT JOIN tickets t ON t.assignee_id=u.id AND t.status IN ('open','in_progress','on_hold')
           WHERE u.role='agent' AND u.active ${req.user.role === 'agent' ? 'AND u.department = $1' : 'AND ($1::text IS NULL OR TRUE)'}
           GROUP BY u.id ORDER BY active_tickets DESC, u.name`, p),
  ]);
  const s = sla.rows[0];
  res.json({
    by_status: Object.fromEntries(byStatus.rows.map(x => [x.status, x.n])),
    by_category: Object.fromEntries(byCategory.rows.map(x => [x.category, x.n])),
    open_breached: s.open_breached,
    at_risk: s.at_risk,
    resolved_total: s.resolved_total,
    sla_compliance_pct: s.resolved_total ? Math.round((s.resolved_in_sla / s.resolved_total) * 100) : null,
    avg_resolution_hours: s.avg_resolution_hours === null ? null : Number(s.avg_resolution_hours),
    agent_workload: workload.rows,
  });
}));
export default r;
