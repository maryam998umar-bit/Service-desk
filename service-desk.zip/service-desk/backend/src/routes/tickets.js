import { Router } from 'express';
import { z } from 'zod';
import { query, tx, audit } from '../db.js';
import { authenticate, requireRole } from '../auth.js';
import { HttpError, wrap } from '../http.js';
import { computeDue, slaState, PRIORITIES } from '../sla.js';
import { CATEGORIES, STATUSES, canTransition, requesterCanTransition, canViewTicket } from '../workflow.js';

const r = Router();
r.use(authenticate);

const createSchema = z.object({
  title: z.string().trim().min(5, 'Title needs at least 5 characters').max(120),
  description: z.string().trim().min(10, 'Describe the problem in at least 10 characters').max(4000),
  category: z.enum(CATEGORIES),
  priority: z.enum(PRIORITIES).default('medium'),
});
const updateSchema = z.object({
  status: z.enum(STATUSES).optional(),
  priority: z.enum(PRIORITIES).optional(),
  assignee_id: z.number().int().positive().nullable().optional(),
}).refine(v => Object.keys(v).length > 0, 'Nothing to update');
const commentSchema = z.object({ body: z.string().trim().min(1, 'Write a comment first').max(2000) });
const idParam = req => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id < 1) throw new HttpError(400, 'Invalid ticket id');
  return id;
};

const withSla = t => ({ ...t, sla_state: slaState(t) });

const SELECT = `
  SELECT t.*, rq.name AS requester_name, a.name AS assignee_name
  FROM tickets t
  JOIN users rq ON rq.id = t.requester_id
  LEFT JOIN users a ON a.id = t.assignee_id`;

// Create. Routing: category picks the department; least-loaded active agent there gets it.
r.post('/', wrap(async (req, res) => {
  const data = createSchema.parse(req.body);
  const ticket = await tx(async c => {
    const now = new Date();
    const { rows: agents } = await c.query(
      `SELECT u.id FROM users u
       LEFT JOIN tickets t ON t.assignee_id = u.id AND t.status IN ('open','in_progress','on_hold')
       WHERE u.role='agent' AND u.active AND u.department=$1
       GROUP BY u.id ORDER BY count(t.id), u.id LIMIT 1`, [data.category]);
    const assignee = agents[0]?.id ?? null;
    const { rows } = await c.query(
      `INSERT INTO tickets (title, description, category, priority, requester_id, assignee_id, sla_due_at, created_at, updated_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$8) RETURNING *`,
      [data.title, data.description, data.category, data.priority, req.user.id, assignee, computeDue(now, data.priority), now]);
    const t = rows[0];
    await audit(c, req.user.id, 'ticket.created', 'ticket', t.id, { category: t.category, priority: t.priority });
    await audit(c, null, assignee ? 'ticket.auto_assigned' : 'ticket.unassigned', 'ticket', t.id, { assignee_id: assignee });
    return t;
  });
  res.status(201).json(withSla(ticket));
}));

r.get('/', wrap(async (req, res) => {
  const filters = z.object({
    status: z.enum(STATUSES).optional(),
    category: z.enum(CATEGORIES).optional(),
    q: z.string().max(100).optional(),
  }).parse(req.query);

  const where = []; const params = [];
  const add = (sql, v) => { params.push(v); where.push(sql.replace('?', `$${params.length}`)); };
  if (req.user.role === 'employee') add('t.requester_id = ?', req.user.id);
  if (req.user.role === 'agent') add('t.category = ?', req.user.department);
  if (filters.status) add('t.status = ?', filters.status);
  if (filters.category) add('t.category = ?', filters.category);
  if (filters.q) add('(t.title ILIKE ? )', `%${filters.q.replace(/[%_]/g, '\\$&')}%`);

  const { rows } = await query(
    `${SELECT} ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY t.created_at DESC LIMIT 200`, params);
  res.json(rows.map(withSla));
}));

async function loadVisible(req, id) {
  const { rows } = await query(`${SELECT} WHERE t.id=$1`, [id]);
  // 404 (not 403) for tickets the user may not see, so ids cannot be enumerated.
  if (!rows[0] || !canViewTicket(req.user, rows[0])) throw new HttpError(404, 'Ticket not found');
  return rows[0];
}

r.get('/:id', wrap(async (req, res) => {
  const ticket = await loadVisible(req, idParam(req));
  const comments = (await query(
    `SELECT c.id, c.body, c.created_at, u.name AS author_name, u.role AS author_role
     FROM ticket_comments c JOIN users u ON u.id=c.author_id WHERE c.ticket_id=$1 ORDER BY c.created_at`, [ticket.id])).rows;
  const history = (await query(
    `SELECT a.action, a.details, a.created_at, u.name AS actor_name
     FROM audit_log a LEFT JOIN users u ON u.id=a.actor_id
     WHERE a.entity='ticket' AND a.entity_id=$1 ORDER BY a.id`, [ticket.id])).rows;
  res.json({ ...withSla(ticket), comments, history });
}));

r.patch('/:id', wrap(async (req, res) => {
  const id = idParam(req);
  const patch = updateSchema.parse(req.body);
  await loadVisible(req, id);

  const updated = await tx(async c => {
    // Row lock so two agents changing the same ticket cannot interleave.
    const { rows } = await c.query('SELECT * FROM tickets WHERE id=$1 FOR UPDATE', [id]);
    const t = rows[0];
    const { role } = req.user;
    const changes = {}; const sets = []; const params = [];
    const set = (col, val) => { params.push(val); sets.push(`${col}=$${params.length}`); };

    if (patch.status && patch.status !== t.status) {
      if (role === 'employee') {
        if (!requesterCanTransition(t.status, patch.status)) throw new HttpError(403, 'You can only close or reopen a resolved request');
      } else if (!canTransition(t.status, patch.status)) {
        throw new HttpError(409, `Cannot move a ${t.status.replace('_', ' ')} request to ${patch.status.replace('_', ' ')}`);
      }
      changes.status = { from: t.status, to: patch.status };
      set('status', patch.status);
      if (patch.status === 'resolved') set('resolved_at', new Date());
      if (t.status === 'resolved' && patch.status === 'in_progress') set('resolved_at', null);
    }
    if (patch.priority && patch.priority !== t.priority) {
      if (role === 'employee') throw new HttpError(403, 'Only agents can change priority');
      changes.priority = { from: t.priority, to: patch.priority };
      set('priority', patch.priority);
      set('sla_due_at', computeDue(t.created_at, patch.priority));
    }
    if (patch.assignee_id !== undefined && patch.assignee_id !== t.assignee_id) {
      if (role !== 'admin') throw new HttpError(403, 'Only admins can reassign requests');
      if (patch.assignee_id !== null) {
        const { rows: a } = await c.query(`SELECT id FROM users WHERE id=$1 AND role='agent' AND active AND department=$2`, [patch.assignee_id, t.category]);
        if (!a[0]) throw new HttpError(400, `Assignee must be an active ${t.category} agent`);
      }
      changes.assignee_id = { from: t.assignee_id, to: patch.assignee_id };
      set('assignee_id', patch.assignee_id);
    }
    if (!sets.length) return t;
    set('updated_at', new Date());
    params.push(id);
    const { rows: out } = await c.query(`UPDATE tickets SET ${sets.join(', ')} WHERE id=$${params.length} RETURNING *`, params);
    await audit(c, req.user.id, 'ticket.updated', 'ticket', id, changes);
    return out[0];
  });
  res.json(withSla(await loadVisible(req, updated.id)));
}));

r.post('/:id/comments', wrap(async (req, res) => {
  const id = idParam(req);
  const { body } = commentSchema.parse(req.body);
  await loadVisible(req, id);
  const row = await tx(async c => {
    const { rows } = await c.query('INSERT INTO ticket_comments (ticket_id, author_id, body) VALUES ($1,$2,$3) RETURNING *', [id, req.user.id, body]);
    await audit(c, req.user.id, 'ticket.commented', 'ticket', id, { comment_id: rows[0].id });
    return rows[0];
  });
  res.status(201).json(row);
}));

export default r;
