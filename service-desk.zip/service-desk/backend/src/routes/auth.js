import { Router } from 'express';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import { query, audit, pool } from '../db.js';
import { signToken, authenticate, loginLimiter, clearAttempts } from '../auth.js';
import { HttpError, wrap } from '../http.js';

const r = Router();
const loginSchema = z.object({ email: z.string().email().max(200), password: z.string().min(1).max(200) });

r.post('/login', loginLimiter, wrap(async (req, res) => {
  const { email, password } = loginSchema.parse(req.body);
  const { rows } = await query('SELECT * FROM users WHERE lower(email)=lower($1)', [email]);
  const user = rows[0];
  // Same message for unknown email and wrong password, so accounts cannot be probed.
  const ok = user && user.active && await bcrypt.compare(password, user.password_hash);
  if (!ok) {
    await audit(pool, user?.id ?? null, 'auth.login_failed', 'user', user?.id ?? null, { email });
    throw new HttpError(401, 'Email or password is incorrect');
  }
  clearAttempts(req);
  await audit(pool, user.id, 'auth.login', 'user', user.id);
  const { password_hash, ...safe } = user;
  res.json({ token: signToken(user), user: safe });
}));

r.get('/me', authenticate, (req, res) => res.json({ user: req.user }));
export default r;
