import { Router } from 'express';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import { query, tx, audit } from '../db.js';
import { authenticate, requireRole } from '../auth.js';
import { HttpError, wrap } from '../http.js';
import { CATEGORIES } from '../workflow.js';

const r = Router();
r.use(authenticate, requireRole('admin'));

const createUser = z.object({
  name: z.string().trim().min(2).max(100),
  email: z.string().email().max(200),
  password: z.string().min(10, 'Password needs at least 10 characters').max(200),
  role: z.enum(['employee', 'agent', 'admin']),
  department: z.enum(CATEGORIES).nullable().optional(),
}).refine(v => v.role !== 'agent' || v.department, { message: 'Agents need a department', path: ['department'] });

const patchUser = z.object({ active: z.boolean().optional(), role: z.enum(['employee', 'agent', 'admin']).optional(), department: z.enum(CATEGORIES).nullable().optional() })
  .refine(v => Object.keys(v).length > 0, 'Nothing to update');

r.get('/users', wrap(async (_req, res) => {
  res.json((await query('SELECT id, name, email, role, department, active, created_at FROM users ORDER BY role, name')).rows);
}));

r.post('/users', wrap(async (req, res) => {
  const d = createUser.parse(req.body);
  const user = await tx(async c => {
    const { rows } = await c.query(
      'INSERT INTO users (name, email, password_hash, role, department) VALUES ($1,lower($2),$3,$4,$5) RETURNING id, name, email, role, department, active',
      [d.name, d.email, await bcrypt.hash(d.password, 10), d.role, d.role === 'agent' ? d.department : null]);
    await audit(c, req.user.id, 'user.created', 'user', rows[0].id, { role: d.role, department: d.department ?? null });
    return rows[0];
  });
  res.status(201).json(user);
}));

r.patch('/users/:id', wrap(async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) throw new HttpError(400, 'Invalid user id');
  const patch = patchUser.parse(req.body);
  if (id === req.user.id && (patch.active === false || (patch.role && patch.role !== 'admin')))
    throw new HttpError(409, 'You cannot deactivate or demote your own account');
  const user = await tx(async c => {
    const { rows: cur } = await c.query('SELECT * FROM users WHERE id=$1 FOR UPDATE', [id]);
    if (!cur[0]) throw new HttpError(404, 'User not found');
    const next = { ...cur[0], ...patch };
    if (next.role !== 'agent') next.department = null;
    if (next.role === 'agent' && !next.department) throw new HttpError(400, 'Agents need a department');
    const { rows } = await c.query(
      'UPDATE users SET active=$1, role=$2, department=$3 WHERE id=$4 RETURNING id, name, email, role, department, active',
      [next.active, next.role, next.department, id]);
    await audit(c, req.user.id, 'user.updated', 'user', id, patch);
    return rows[0];
  });
  res.json(user);
}));

r.get('/audit', wrap(async (req, res) => {
  const limit = Math.min(Number(req.query.limit) || 100, 500);
  res.json((await query(
    `SELECT a.id, a.action, a.entity, a.entity_id, a.details, a.created_at, u.name AS actor_name
     FROM audit_log a LEFT JOIN users u ON u.id=a.actor_id ORDER BY a.id DESC LIMIT $1`, [limit])).rows);
}));
export default r;
