import { app } from './app.js';
import { runMigrations } from './migrate.js';
import { seedIfEmpty } from './seed.js';

for (const k of ['DATABASE_URL', 'JWT_SECRET']) {
  if (!process.env[k]) { console.error(`Missing required env var ${k}`); process.exit(1); }
}
if (process.env.JWT_SECRET.length < 32) { console.error('JWT_SECRET must be at least 32 characters'); process.exit(1); }

await runMigrations();
if (process.env.SEED_DEMO_DATA === 'true') await seedIfEmpty();
const port = Number(process.env.PORT) || 4000;
app.listen(port, () => console.log(`API listening on :${port}`));
