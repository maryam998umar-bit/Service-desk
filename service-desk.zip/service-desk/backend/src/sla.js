// Resolution targets by priority, in hours. Wall-clock time (no business-hours calendar).
export const SLA_HOURS = { critical: 4, high: 8, medium: 24, low: 72 };
export const PRIORITIES = Object.keys(SLA_HOURS);
const AT_RISK_FRACTION = 0.25; // last 25% of the window

export function computeDue(createdAt, priority) {
  const hours = SLA_HOURS[priority];
  if (!hours) throw new Error(`Unknown priority: ${priority}`);
  return new Date(new Date(createdAt).getTime() + hours * 3600_000);
}

/** met | breached | at_risk | on_track */
export function slaState({ created_at, sla_due_at, resolved_at }, now = new Date()) {
  const created = new Date(created_at).getTime();
  const due = new Date(sla_due_at).getTime();
  if (resolved_at) return new Date(resolved_at).getTime() <= due ? 'met' : 'breached';
  const t = now.getTime();
  if (t > due) return 'breached';
  return (due - t) / (due - created) < AT_RISK_FRACTION ? 'at_risk' : 'on_track';
}
