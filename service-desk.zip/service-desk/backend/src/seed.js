import bcrypt from 'bcryptjs';
import { fileURLToPath } from 'node:url';
import { pool, query, tx, audit } from './db.js';
import { computeDue } from './sla.js';

export const DEMO_PASSWORD = 'Demo-Passw0rd!';
const hoursAgo = h => new Date(Date.now() - h * 3600_000);

const USERS = [
  ['Asha Admin', 'admin@acme.test', 'admin', null],
  ['Ivan IT', 'it.agent@acme.test', 'agent', 'IT'],
  ['Ines IT', 'it.agent2@acme.test', 'agent', 'IT'],
  ['Hana HR', 'hr.agent@acme.test', 'agent', 'HR'],
  ['Farid Facilities', 'facility.agent@acme.test', 'agent', 'FACILITY'],
  ['Eli Employee', 'eli@acme.test', 'employee', null],
  ['Maya Employee', 'maya@acme.test', 'employee', null],
];
// title, description, category, priority, requester email, assignee email, status, created hours ago, resolved hours after creation
const TICKETS = [
  ['VPN drops every 10 minutes', 'Working from home, VPN disconnects roughly every ten minutes since Monday.', 'IT', 'high', 'eli@acme.test', 'it.agent@acme.test', 'in_progress', 6, null],
  ['Laptop will not boot', 'Black screen after the Windows update, fan runs but nothing displays.', 'IT', 'critical', 'maya@acme.test', 'it.agent2@acme.test', 'open', 5, null],
  ['Need access to finance share', 'Joining the finance project, need read access to the shared drive.', 'IT', 'medium', 'eli@acme.test', 'it.agent@acme.test', 'resolved', 30, 10],
  ['Payslip shows wrong tax code', 'October payslip uses an old tax code, please correct before next run.', 'HR', 'high', 'maya@acme.test', 'hr.agent@acme.test', 'in_progress', 9, null],
  ['Parental leave policy question', 'Where can I find the current parental leave policy document?', 'HR', 'low', 'eli@acme.test', 'hr.agent@acme.test', 'closed', 100, 20],
  ['Meeting room 3 projector flickers', 'The projector in room 3 flickers during presentations.', 'FACILITY', 'medium', 'maya@acme.test', 'facility.agent@acme.test', 'open', 20, null],
  ['Broken chair at desk 14B', 'Gas lift on my chair has failed, chair sinks when I sit.', 'FACILITY', 'low', 'eli@acme.test', 'facility.agent@acme.test', 'resolved', 60, 80],
];

export async function seedIfEmpty() {
  const { rows } = await query('SELECT count(*)::int AS n FROM users');
  if (rows[0].n > 0) return false;
  const hash = await bcrypt.hash(DEMO_PASSWORD, 10);
  await tx(async c => {
    const ids = {};
    for (const [name, email, role, department] of USERS) {
      const r = await c.query('INSERT INTO users (name,email,password_hash,role,department) VALUES ($1,$2,$3,$4,$5) RETURNING id', [name, email, hash, role, department]);
      ids[email] = r.rows[0].id;
    }
    for (const [title, description, category, priority, req, asg, status, ago, resAfter] of TICKETS) {
      const created = hoursAgo(ago);
      const resolvedAt = resAfter === null ? null : new Date(created.getTime() + resAfter * 3600_000);
      const r = await c.query(
        `INSERT INTO tickets (title,description,category,priority,status,requester_id,assignee_id,sla_due_at,resolved_at,created_at,updated_at)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$10) RETURNING id`,
        [title, description, category, priority, status, ids[req], ids[asg], computeDue(created, priority), resolvedAt, created]);
      await audit(c, ids[req], 'ticket.created', 'ticket', r.rows[0].id, { category, priority });
    }
    await audit(c, null, 'system.seeded', 'system', null, { users: USERS.length, tickets: TICKETS.length });
  });
  console.log(`Seeded demo data. All demo users share the password: ${DEMO_PASSWORD}`);
  return true;
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  seedIfEmpty().then(() => pool.end()).catch(e => { console.error(e); process.exit(1); });
}
