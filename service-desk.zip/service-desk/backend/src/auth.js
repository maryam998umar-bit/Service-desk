import jwt from 'jsonwebtoken';
import { query } from './db.js';
import { HttpError, wrap } from './http.js';

export const signToken = user =>
  jwt.sign({ sub: user.id }, process.env.JWT_SECRET, { expiresIn: '8h' });

// Loads the user on every request so a deactivated account or changed role takes effect immediately.
export const authenticate = wrap(async (req, _res, next) => {
  const header = req.headers.authorization || '';
  if (!header.startsWith('Bearer ')) throw new HttpError(401, 'Sign in required');
  let payload;
  try { payload = jwt.verify(header.slice(7), process.env.JWT_SECRET); }
  catch { throw new HttpError(401, 'Session expired. Sign in again'); }
  const { rows } = await query('SELECT id, name, email, role, department, active FROM users WHERE id=$1', [payload.sub]);
  if (!rows[0] || !rows[0].active) throw new HttpError(401, 'Account is not active');
  req.user = rows[0];
  next();
});

export const requireRole = (...roles) => (req, _res, next) =>
  roles.includes(req.user.role) ? next() : next(new HttpError(403, 'You do not have access to this'));

// Tiny in-memory limiter for login attempts: 10 per 15 min per IP+email.
const attempts = new Map();
const keyOf = req => `${req.ip}:${String(req.body?.email || '').toLowerCase()}`;
export function loginLimiter(req, _res, next) {
  const key = keyOf(req);
  const now = Date.now();
  const recent = (attempts.get(key) || []).filter(t => now - t < 15 * 60_000);
  if (recent.length >= 10) return next(new HttpError(429, 'Too many sign-in attempts. Try again in 15 minutes'));
  recent.push(now); attempts.set(key, recent);
  next();
}
export const clearAttempts = req => attempts.delete(keyOf(req));
