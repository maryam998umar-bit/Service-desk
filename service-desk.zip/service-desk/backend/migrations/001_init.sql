CREATE TABLE users (
  id            SERIAL PRIMARY KEY,
  name          TEXT NOT NULL,
  email         TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role          TEXT NOT NULL CHECK (role IN ('employee','agent','admin')),
  department    TEXT CHECK (department IN ('IT','HR','FACILITY')),
  active        BOOLEAN NOT NULL DEFAULT TRUE,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (role <> 'agent' OR department IS NOT NULL)
);

CREATE TABLE tickets (
  id           SERIAL PRIMARY KEY,
  title        TEXT NOT NULL CHECK (char_length(title) BETWEEN 5 AND 120),
  description  TEXT NOT NULL CHECK (char_length(description) BETWEEN 10 AND 4000),
  category     TEXT NOT NULL CHECK (category IN ('IT','HR','FACILITY')),
  priority     TEXT NOT NULL CHECK (priority IN ('low','medium','high','critical')),
  status       TEXT NOT NULL DEFAULT 'open'
               CHECK (status IN ('open','in_progress','on_hold','resolved','closed')),
  requester_id INT NOT NULL REFERENCES users(id),
  assignee_id  INT REFERENCES users(id),
  sla_due_at   TIMESTAMPTZ NOT NULL,
  resolved_at  TIMESTAMPTZ,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX tickets_requester_idx ON tickets(requester_id);
CREATE INDEX tickets_category_status_idx ON tickets(category, status);
CREATE INDEX tickets_assignee_idx ON tickets(assignee_id);

CREATE TABLE ticket_comments (
  id         SERIAL PRIMARY KEY,
  ticket_id  INT NOT NULL REFERENCES tickets(id) ON DELETE CASCADE,
  author_id  INT NOT NULL REFERENCES users(id),
  body       TEXT NOT NULL CHECK (char_length(body) BETWEEN 1 AND 2000),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX comments_ticket_idx ON ticket_comments(ticket_id);

-- Append-only record of who did what. Application code only INSERTs.
CREATE TABLE audit_log (
  id         BIGSERIAL PRIMARY KEY,
  actor_id   INT REFERENCES users(id),
  action     TEXT NOT NULL,
  entity     TEXT NOT NULL,
  entity_id  INT,
  details    JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX audit_entity_idx ON audit_log(entity, entity_id);
