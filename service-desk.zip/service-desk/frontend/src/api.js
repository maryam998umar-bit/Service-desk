let token = localStorage.getItem('sd_token');
export const setToken = t => { token = t; t ? localStorage.setItem('sd_token', t) : localStorage.removeItem('sd_token'); };
export const hasToken = () => Boolean(token);

export async function api(path, { method = 'GET', body } = {}) {
  const res = await fetch(`/api${path}`, {
    method,
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const err = new Error(data.error || 'Request failed');
    err.status = res.status; err.details = data.details;
    throw err;
  }
  return data;
}
