import { useEffect, useState, useCallback } from 'react';
import { api, setToken, hasToken } from './api.js';

const CATEGORIES = ['IT', 'HR', 'FACILITY'];
const PRIORITIES = ['low', 'medium', 'high', 'critical'];
const label = s => s.replace('_', ' ');
const when = d => new Date(d).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' });
const errText = e => (e.details?.length ? e.details.map(d => `${d.field ? d.field + ': ' : ''}${d.message}`).join('. ') : e.message);

// Next statuses offered in the UI. The server enforces the real rules.
const AGENT_NEXT = { open: ['in_progress', 'on_hold', 'resolved'], in_progress: ['open', 'on_hold', 'resolved'], on_hold: ['in_progress'], resolved: ['closed', 'in_progress'], closed: [] };

function duration(ms) {
  const m = Math.round(Math.abs(ms) / 60000), h = Math.floor(m / 60), d = Math.floor(h / 24);
  return d >= 1 ? `${d}d ${h % 24}h` : h >= 1 ? `${h}h ${m % 60}m` : `${m}m`;
}

/* The SLA clock: bar = share of the resolution window already used. */
function SlaClock({ t }) {
  const created = new Date(t.created_at).getTime(), due = new Date(t.sla_due_at).getTime();
  const end = t.resolved_at ? new Date(t.resolved_at).getTime() : Date.now();
  const used = Math.min(1, Math.max(0, (end - created) / (due - created)));
  const text = { met: `Met, ${duration(due - end)} to spare`, breached: t.resolved_at ? `Missed by ${duration(end - due)}` : `Overdue ${duration(end - due)}`, at_risk: `${duration(due - end)} left`, on_track: `${duration(due - end)} left` }[t.sla_state];
  return (
    <div className={`sla sla-${t.sla_state}`} title={`Due ${when(t.sla_due_at)}`}>
      <div className="sla-track"><div className="sla-fill" style={{ width: `${used * 100}%` }} /></div>
      <span>{text}</span>
    </div>
  );
}

function Login({ onDone }) {
  const [email, setEmail] = useState(''); const [password, setPassword] = useState(''); const [err, setErr] = useState(''); const [busy, setBusy] = useState(false);
  async function submit(e) {
    e.preventDefault(); setBusy(true); setErr('');
    try { const r = await api('/auth/login', { method: 'POST', body: { email, password } }); setToken(r.token); onDone(r.user); }
    catch (x) { setErr(errText(x)); } finally { setBusy(false); }
  }
  return (
    <main className="login">
      <form onSubmit={submit} className="login-card">
        <h1>Service Desk</h1>
        <p className="muted">Raise and track IT, HR and facilities requests.</p>
        <label>Work email<input type="email" value={email} onChange={e => setEmail(e.target.value)} autoComplete="username" required /></label>
        <label>Password<input type="password" value={password} onChange={e => setPassword(e.target.value)} autoComplete="current-password" required /></label>
        {err && <p className="error" role="alert">{err}</p>}
        <button className="primary" disabled={busy}>{busy ? 'Signing in…' : 'Sign in'}</button>
        <p className="muted small">Demo accounts: admin@acme.test, it.agent@acme.test, eli@acme.test. Password: Demo-Passw0rd!</p>
      </form>
    </main>
  );
}

function NewTicket({ onClose, onCreated }) {
  const [f, setF] = useState({ title: '', description: '', category: 'IT', priority: 'medium' });
  const [err, setErr] = useState(''); const [busy, setBusy] = useState(false);
  const up = k => e => setF({ ...f, [k]: e.target.value });
  async function submit(e) {
    e.preventDefault(); setBusy(true); setErr('');
    try { const t = await api('/tickets', { method: 'POST', body: f }); onCreated(t); } catch (x) { setErr(errText(x)); setBusy(false); }
  }
  return (
    <div className="overlay" onClick={onClose}>
      <form className="sheet" onClick={e => e.stopPropagation()} onSubmit={submit}>
        <h2>New request</h2>
        <label>Title<input value={f.title} onChange={up('title')} maxLength={120} required /></label>
        <label>What is happening?<textarea rows={5} value={f.description} onChange={up('description')} required /></label>
        <div className="row">
          <label>Team<select value={f.category} onChange={up('category')}>{CATEGORIES.map(c => <option key={c}>{c}</option>)}</select></label>
          <label>Priority<select value={f.priority} onChange={up('priority')}>{PRIORITIES.map(p => <option key={p}>{p}</option>)}</select></label>
        </div>
        {err && <p className="error" role="alert">{err}</p>}
        <div className="row end"><button type="button" onClick={onClose}>Cancel</button><button className="primary" disabled={busy}>Submit request</button></div>
      </form>
    </div>
  );
}

function TicketDetail({ id, user, agents, onClose, onChanged }) {
  const [t, setT] = useState(null); const [err, setErr] = useState(''); const [comment, setComment] = useState('');
  const load = useCallback(() => api(`/tickets/${id}`).then(setT).catch(e => setErr(errText(e))), [id]);
  useEffect(() => { load(); }, [load]);
  async function patch(body) { setErr(''); try { await api(`/tickets/${id}`, { method: 'PATCH', body }); await load(); onChanged(); } catch (e) { setErr(errText(e)); } }
  async function addComment(e) { e.preventDefault(); setErr(''); try { await api(`/tickets/${id}/comments`, { method: 'POST', body: { body: comment } }); setComment(''); await load(); } catch (x) { setErr(errText(x)); } }
  if (!t) return <aside className="detail"><button onClick={onClose}>Close</button><p className={err ? 'error' : 'muted'}>{err || 'Loading…'}</p></aside>;
  const isStaff = user.role !== 'employee';
  const nextOptions = isStaff ? AGENT_NEXT[t.status] : t.status === 'resolved' ? ['closed', 'in_progress'] : [];
  const sameDept = agents.filter(a => a.department === t.category && a.active);
  return (
    <aside className="detail">
      <div className="row between"><span className="muted">Request #{t.id}</span><button onClick={onClose}>Close</button></div>
      <h2>{t.title}</h2>
      <SlaClock t={t} />
      <dl className="facts">
        <dt>Status</dt><dd><span className={`pill s-${t.status}`}>{label(t.status)}</span></dd>
        <dt>Team</dt><dd>{t.category}</dd>
        <dt>Priority</dt><dd>{t.priority}</dd>
        <dt>Requested by</dt><dd>{t.requester_name}</dd>
        <dt>Assigned to</dt><dd>{t.assignee_name || 'Nobody yet'}</dd>
        <dt>Opened</dt><dd>{when(t.created_at)}</dd>
      </dl>
      <p className="body-text">{t.description}</p>
      {err && <p className="error" role="alert">{err}</p>}
      {nextOptions.length > 0 && (
        <div className="row wrap">{nextOptions.map(s => <button key={s} onClick={() => patch({ status: s })}>{t.status === 'resolved' && s === 'in_progress' ? 'Reopen' : `Mark ${label(s)}`}</button>)}</div>
      )}
      {isStaff && <label>Priority<select value={t.priority} onChange={e => patch({ priority: e.target.value })}>{PRIORITIES.map(p => <option key={p}>{p}</option>)}</select></label>}
      {user.role === 'admin' && (
        <label>Assignee<select value={t.assignee_id ?? ''} onChange={e => patch({ assignee_id: e.target.value ? Number(e.target.value) : null })}>
          <option value="">Unassigned</option>{sameDept.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
        </select></label>
      )}
      <h3>Conversation</h3>
      {t.comments.length === 0 && <p className="muted">No comments yet.</p>}
      {t.comments.map(c => <div key={c.id} className="comment"><b>{c.author_name}</b> <span className="muted small">{when(c.created_at)}</span><p>{c.body}</p></div>)}
      <form onSubmit={addComment} className="row"><input value={comment} onChange={e => setComment(e.target.value)} placeholder="Add a comment" maxLength={2000} /><button className="primary" disabled={!comment.trim()}>Post</button></form>
      <h3>History</h3>
      <ul className="history">{t.history.map((h, i) => <li key={i}><span className="muted small">{when(h.created_at)}</span> {h.actor_name || 'System'}: {h.action.replace('ticket.', '').replace('_', ' ')}{h.details?.status ? ` (${label(h.details.status.from)} to ${label(h.details.status.to)})` : ''}</li>)}</ul>
    </aside>
  );
}

function Tickets({ user, agents }) {
  const [rows, setRows] = useState(null); const [err, setErr] = useState('');
  const [status, setStatus] = useState(''); const [category, setCategory] = useState(''); const [q, setQ] = useState('');
  const [open, setOpen] = useState(null); const [creating, setCreating] = useState(false);
  const load = useCallback(() => {
    const p = new URLSearchParams(Object.entries({ status, category, q }).filter(([, v]) => v));
    api(`/tickets?${p}`).then(setRows).catch(e => setErr(errText(e)));
  }, [status, category, q]);
  useEffect(() => { const t = setTimeout(load, 200); return () => clearTimeout(t); }, [load]);
  return (
    <section className={open ? 'with-detail' : ''}>
      <div className="list">
        <div className="row between"><h1>{user.role === 'employee' ? 'My requests' : user.role === 'agent' ? `${user.department} queue` : 'All requests'}</h1><button className="primary" onClick={() => setCreating(true)}>New request</button></div>
        <div className="row wrap filters">
          <input placeholder="Search titles" value={q} onChange={e => setQ(e.target.value)} />
          <select value={status} onChange={e => setStatus(e.target.value)}><option value="">Any status</option>{['open', 'in_progress', 'on_hold', 'resolved', 'closed'].map(s => <option key={s} value={s}>{label(s)}</option>)}</select>
          {user.role === 'admin' && <select value={category} onChange={e => setCategory(e.target.value)}><option value="">Any team</option>{CATEGORIES.map(c => <option key={c}>{c}</option>)}</select>}
        </div>
        {err && <p className="error" role="alert">{err}</p>}
        {rows === null ? <p className="muted">Loading…</p> : rows.length === 0 ? <p className="empty">No requests match. {user.role === 'employee' && 'Use “New request” to raise one.'}</p> : (
          <div className="table-wrap"><table>
            <thead><tr><th>Request</th><th>Team</th><th>Status</th><th>Assigned to</th><th>SLA</th></tr></thead>
            <tbody>{rows.map(t => (
              <tr key={t.id} className={open === t.id ? 'active' : ''} onClick={() => setOpen(t.id)} tabIndex={0} onKeyDown={e => e.key === 'Enter' && setOpen(t.id)}>
                <td><b>{t.title}</b><div className="muted small">#{t.id} · {t.requester_name} · {t.priority}</div></td>
                <td>{t.category}</td><td><span className={`pill s-${t.status}`}>{label(t.status)}</span></td><td>{t.assignee_name || '—'}</td><td><SlaClock t={t} /></td>
              </tr>))}</tbody>
          </table></div>)}
      </div>
      {open && <TicketDetail key={open} id={open} user={user} agents={agents} onClose={() => setOpen(null)} onChanged={load} />}
      {creating && <NewTicket onClose={() => setCreating(false)} onCreated={t => { setCreating(false); load(); setOpen(t.id); }} />}
    </section>
  );
}

function Bars({ data, order }) {
  const max = Math.max(1, ...Object.values(data));
  return <div className="bars">{order.map(k => <div key={k} className="bar-row"><span>{label(k)}</span><div className="bar"><div style={{ width: `${((data[k] || 0) / max) * 100}%` }} /></div><b>{data[k] || 0}</b></div>)}</div>;
}
function Dashboard() {
  const [d, setD] = useState(null); const [err, setErr] = useState('');
  useEffect(() => { api('/dashboard').then(setD).catch(e => setErr(errText(e))); }, []);
  if (err) return <p className="error">{err}</p>;
  if (!d) return <p className="muted">Loading…</p>;
  return (
    <section className="page">
      <h1>Dashboard</h1>
      <div className="stats">
        <div className={`stat ${d.open_breached ? 'bad' : ''}`}><b>{d.open_breached}</b><span>open requests past SLA</span></div>
        <div className={`stat ${d.at_risk ? 'warn' : ''}`}><b>{d.at_risk}</b><span>at risk (last 25% of window)</span></div>
        <div className="stat"><b>{d.sla_compliance_pct === null ? '—' : `${d.sla_compliance_pct}%`}</b><span>resolved within SLA</span></div>
        <div className="stat"><b>{d.avg_resolution_hours === null ? '—' : `${d.avg_resolution_hours}h`}</b><span>average time to resolve</span></div>
      </div>
      <div className="two">
        <div><h3>By status</h3><Bars data={d.by_status} order={['open', 'in_progress', 'on_hold', 'resolved', 'closed']} /></div>
        <div><h3>By team</h3><Bars data={d.by_category} order={CATEGORIES} /></div>
      </div>
      <h3>Agent workload (active requests)</h3>
      <Bars data={Object.fromEntries(d.agent_workload.map(a => [a.name, a.active_tickets]))} order={d.agent_workload.map(a => a.name)} />
    </section>
  );
}

function Admin({ me }) {
  const [users, setUsers] = useState([]); const [log, setLog] = useState([]); const [err, setErr] = useState('');
  const [f, setF] = useState({ name: '', email: '', password: '', role: 'employee', department: 'IT' });
  const load = () => { api('/admin/users').then(setUsers).catch(e => setErr(errText(e))); api('/admin/audit?limit=60').then(setLog).catch(() => {}); };
  useEffect(load, []);
  async function create(e) {
    e.preventDefault(); setErr('');
    try { await api('/admin/users', { method: 'POST', body: { ...f, department: f.role === 'agent' ? f.department : null } }); setF({ ...f, name: '', email: '', password: '' }); load(); } catch (x) { setErr(errText(x)); }
  }
  async function toggle(u) { setErr(''); try { await api(`/admin/users/${u.id}`, { method: 'PATCH', body: { active: !u.active } }); load(); } catch (x) { setErr(errText(x)); } }
  return (
    <section className="page">
      <h1>People and audit</h1>
      {err && <p className="error" role="alert">{err}</p>}
      <form onSubmit={create} className="row wrap add-user">
        <input placeholder="Full name" value={f.name} onChange={e => setF({ ...f, name: e.target.value })} required />
        <input type="email" placeholder="Email" value={f.email} onChange={e => setF({ ...f, email: e.target.value })} required />
        <input type="password" placeholder="Password (10+ characters)" value={f.password} onChange={e => setF({ ...f, password: e.target.value })} required />
        <select value={f.role} onChange={e => setF({ ...f, role: e.target.value })}><option>employee</option><option>agent</option><option>admin</option></select>
        {f.role === 'agent' && <select value={f.department} onChange={e => setF({ ...f, department: e.target.value })}>{CATEGORIES.map(c => <option key={c}>{c}</option>)}</select>}
        <button className="primary">Add person</button>
      </form>
      <div className="table-wrap"><table><thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Team</th><th></th></tr></thead>
        <tbody>{users.map(u => <tr key={u.id} className={u.active ? '' : 'inactive'}><td>{u.name}</td><td>{u.email}</td><td>{u.role}</td><td>{u.department || '—'}</td>
          <td>{u.id !== me.id && <button onClick={() => toggle(u)}>{u.active ? 'Deactivate' : 'Reactivate'}</button>}</td></tr>)}</tbody></table></div>
      <h3>Recent activity</h3>
      <ul className="history">{log.map(a => <li key={a.id}><span className="muted small">{when(a.created_at)}</span> {a.actor_name || 'System'}: {a.action}{a.entity_id ? ` (${a.entity} #${a.entity_id})` : ''}</li>)}</ul>
    </section>
  );
}

export default function App() {
  const [user, setUser] = useState(null); const [ready, setReady] = useState(!hasToken());
  const [view, setView] = useState('tickets'); const [agents, setAgents] = useState([]);
  useEffect(() => { if (hasToken()) api('/auth/me').then(r => setUser(r.user)).catch(() => setToken(null)).finally(() => setReady(true)); }, []);
  useEffect(() => { if (user?.role === 'admin') api('/admin/users').then(setAgents).catch(() => {}); }, [user]);
  if (!ready) return null;
  if (!user) return <Login onDone={u => { setUser(u); setView('tickets'); }} />;
  const staff = user.role !== 'employee';
  const tabs = [['tickets', 'Requests'], ...(staff ? [['dashboard', 'Dashboard']] : []), ...(user.role === 'admin' ? [['admin', 'People and audit']] : [])];
  return (
    <div className="shell">
      <nav>
        <div className="brand">Service Desk</div>
        {tabs.map(([k, l]) => <button key={k} className={view === k ? 'nav-on' : ''} onClick={() => setView(k)}>{l}</button>)}
        <div className="spacer" />
        <div className="me"><b>{user.name}</b><span>{user.role}{user.department ? `, ${user.department}` : ''}</span></div>
        <button onClick={() => { setToken(null); setUser(null); }}>Sign out</button>
      </nav>
      <main>
        {view === 'tickets' && <Tickets user={user} agents={agents} />}
        {view === 'dashboard' && staff && <Dashboard />}
        {view === 'admin' && user.role === 'admin' && <Admin me={user} />}
      </main>
    </div>
  );
}
