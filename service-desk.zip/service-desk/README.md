# Employee Service Request System

Internal portal where employees raise IT, HR and facilities requests. Requests are routed to the right team, tracked against SLA deadlines, and summarised on a dashboard. Built for Arrowstack Full Stack Internship, Project 2.

**Stack:** React (Vite), Node.js + Express REST API, PostgreSQL, JWT auth with role-based access, Docker Compose.

## Run it

```bash
cp .env.example .env        # then edit DB_PASSWORD and JWT_SECRET (32+ chars)
docker compose up --build
```

Open http://localhost:8080. Demo data is seeded on first start (`SEED_DEMO_DATA=true`). Every demo user has the password `Demo-Passw0rd!`.

| Email | Role |
|---|---|
| admin@acme.test | admin (everything, people, audit log) |
| it.agent@acme.test, it.agent2@acme.test | agent, IT |
| hr.agent@acme.test | agent, HR |
| facility.agent@acme.test | agent, Facility |
| eli@acme.test, maya@acme.test | employee |

Set `SEED_DEMO_DATA=false` for anything that is not a demo.

### Without Docker
```bash
# backend (needs a running PostgreSQL)
cd backend && npm install
DATABASE_URL=postgres://user:pass@localhost:5432/servicedesk JWT_SECRET=<32+ chars> SEED_DEMO_DATA=true npm start
# frontend (proxies /api to :4000)
cd frontend && npm install && npm run dev      # http://localhost:5173
# unit tests (no database or install needed)
cd backend && npm test
```

## What it does

- **Roles:** employee (own requests), agent (their department's queue), admin (all requests, people, audit log). Enforced on the server on every call; the user is reloaded from the database each request, so deactivation and role changes apply immediately.
- **Routing:** the category (IT / HR / FACILITY) picks the department; the active agent there with the fewest open requests is assigned automatically. Admins can reassign within the department.
- **SLA:** resolution targets by priority: critical 4h, high 8h, medium 24h, low 72h. States: on track, at risk (last 25% of the window), breached, met. Changing priority recalculates the deadline from the original creation time.
- **Workflow:** open, in progress, on hold, resolved, closed. Invalid jumps are rejected (409). Requesters can only close or reopen a resolved request.
- **Dashboard (agents, admins):** requests past SLA, at risk, SLA compliance %, average time to resolve, counts by status and team, agent workload. Agents see their department only.
- **Audit trail:** `audit_log` is insert-only and records logins (including failures), ticket creation, assignment, every status/priority/assignee change, comments and user changes. Each ticket shows its own history; admins see the global log.

## API

| Method and path | Who | Purpose |
|---|---|---|
| POST /api/auth/login | public | Returns JWT (8h) |
| GET /api/auth/me | any | Current user |
| POST /api/tickets | any | Create request |
| GET /api/tickets?status=&category=&q= | any (scoped) | List, max 200 |
| GET /api/tickets/:id | any (scoped) | Detail, comments, history |
| PATCH /api/tickets/:id | scoped by role | status, priority, assignee_id |
| POST /api/tickets/:id/comments | any (scoped) | Add comment |
| GET /api/dashboard | agent, admin | Metrics |
| GET/POST /api/admin/users, PATCH /api/admin/users/:id | admin | Manage people |
| GET /api/admin/audit | admin | Global audit log |

Errors are JSON: `{ "error": "...", "details": [{ "field", "message" }] }`.

## Layout

```
backend/migrations/   SQL migrations, applied in order on start (tracked in schema_migrations)
backend/src/          app, routes/, sla.js and workflow.js (pure logic), auth, seed
backend/test/         unit tests for SLA and workflow rules
frontend/src/         React app
docs/                 requirements, decision log, test evidence
```

## Known limitations

See `docs/requirements.md` section 6. The main ones: SLA uses wall-clock hours (no business calendar), on-hold time does not pause the clock, no email notifications, login rate limiting is in-memory (per process).
