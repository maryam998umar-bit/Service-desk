# Requirements

## 1. Stakeholders and decision
- **Primary stakeholder:** the IT/HR/Facilities service manager.
- **Decision the system enables:** where to add or move agent capacity this week, based on SLA breaches, at-risk requests and workload per agent.
- **Other users:** employees (raise and track requests), agents (work a queue), admin (people, reassignment, audit).

## 2. Scope
In: request lifecycle, routing, SLA tracking, role-based access, dashboard, audit log, user management.
Out: email/Slack notifications, file attachments, business-hours calendars, SSO, multi-tenant.

## 3. Success metrics
| Metric | Target |
|---|---|
| Every request is routed to a department queue on creation | 100% (assigned when an active agent exists) |
| Employees can see only their own requests | 0 cross-user reads in tests |
| SLA state is visible on every open request | list and detail |
| Every state change is attributable | one audit row per change, with actor |
| Mentor can run it from the README | `docker compose up` works with a copied `.env` |

## 4. Required features mapped to implementation
| Required feature | Where |
|---|---|
| Role-based access | `auth.js` (`authenticate`, `requireRole`), `workflow.canViewTicket`, scoped queries in `routes/tickets.js` |
| REST API integration | `backend/src/routes/*`, `frontend/src/api.js` |
| Relational DB with migrations | `backend/migrations/001_init.sql`, `migrate.js` |
| Validation and error handling | zod schemas in routes, DB CHECK constraints, central `errorHandler` |
| Audit-friendly records | `audit_log` table, `audit()` helper, ticket history view, admin audit view |
| Deployment-ready configuration | `docker-compose.yml`, Dockerfiles, `.env.example`, required-env checks, healthcheck |

## 5. Edge cases handled
- Invalid or missing fields (title/description length, unknown category or priority) return 400 with field messages.
- Non-numeric or unknown ticket ids return 400/404; tickets a user cannot see return 404, not 403, so ids cannot be enumerated.
- Illegal status jumps (for example open to closed) return 409.
- Two agents editing the same ticket: row lock (`SELECT ... FOR UPDATE`) inside a transaction.
- No active agent in a department: the ticket is created unassigned and the audit log records `ticket.unassigned`.
- Reassigning to an agent from another department, or an inactive one, is rejected.
- Deactivated user with a still-valid token is rejected on the next request.
- Admin cannot deactivate or demote their own account.
- Login errors do not reveal whether the email exists; repeated attempts are rate limited.
- LIKE wildcards in search text are escaped.
- Reopening a resolved request clears `resolved_at` so SLA is measured again.

## 6. Limitations and next improvements
1. SLA is wall-clock time; add a business-hours calendar per team.
2. On-hold time still counts toward SLA; add a pause/resume clock.
3. No notifications; add email on assignment, at-risk and breach.
4. Login rate limiter is in-memory and resets on restart; move to Redis or the database for multiple instances.
5. JWT lives in localStorage; for production prefer an httpOnly cookie with CSRF protection.
6. Ticket list is capped at 200 with no pagination; add cursor pagination.
7. Automated tests cover business rules only; add API integration tests against a test database.
8. Auto-assignment is least-loaded only; add skills or on-call rotation.
