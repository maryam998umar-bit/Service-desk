# Test and validation evidence

## Automated (run in the authoring environment)
`cd backend && npm test` runs 8 tests on SLA calculation, SLA state boundaries, status transitions, requester permissions and ticket visibility.
Result: **8 passed, 0 failed.** Full output in `unit-test-output.txt`.

## Not yet run: end-to-end checks
The authoring environment had no network access, Docker or PostgreSQL, so the API routes, SQL and React UI were syntax-checked but **not executed against a database**. Before submission, run the checklist below with `docker compose up --build` and record the result and date in the last column.

| # | Check | Expected | Result |
|---|---|---|---|
| 1 | Sign in as eli@acme.test with a wrong password | 401, "Email or password is incorrect" | |
| 2 | Eli opens "My requests" | Only Eli's tickets (3 seeded) | |
| 3 | Eli requests GET /api/tickets/4 (Maya's ticket) | 404 | |
| 4 | Eli creates a critical IT request | Appears with 4h SLA, auto-assigned to the less loaded IT agent | |
| 5 | Eli tries PATCH status=resolved on an open ticket | 403 | |
| 6 | Agent it.agent moves open to closed | 409 | |
| 7 | Agent it.agent moves in progress to resolved | Status changes, history row added | |
| 8 | Eli closes the resolved ticket | Status closed | |
| 9 | Agent hr.agent opens an IT ticket id | 404 | |
| 10 | Admin reassigns an IT ticket to an HR agent | 400 | |
| 11 | Admin creates a user with a 6-character password | 400 with field message | |
| 12 | Admin deactivates Maya, Maya reuses her old token | 401 | |
| 13 | Dashboard as admin | Seeded data shows breached and at-risk counts | |
| 14 | Dashboard as eli (employee) | 403 | |
| 15 | 11 wrong logins in 15 minutes | 429 | |
| 16 | `docker compose down && up` | Data persists; no duplicate seed | |
