# Decision log

| # | Decision | Why | Trade-off |
|---|---|---|---|
| 1 | Plain SQL migrations with a small runner | Transparent, no ORM to learn, reviewable by a mentor | No automatic down-migrations |
| 2 | Express + zod rather than NestJS | Smaller surface for a one-month project; schemas double as documentation | Less structure than NestJS modules |
| 3 | SLA and workflow rules in dependency-free modules | Can be unit tested with no database | Rules live in code, not configurable at runtime |
| 4 | Load the user from the database on every request | Role changes and deactivation take effect at once | One extra indexed query per request |
| 5 | 404 for tickets outside a user's scope | Prevents enumeration of ids | Slightly harder to debug |
| 6 | Row lock on ticket update | Prevents lost updates between agents | Short lock held during the update |
| 7 | Audit table is insert-only by convention | Simple and queryable | Not tamper-proof; production would add DB-level grants or an external log |
| 8 | Priority change recalculates SLA from creation time | A ticket escalated late is correctly already late | Could surprise users; documented |
| 9 | Auto-assign to least-loaded agent in the department | Fair and easy to explain | Ignores skills and availability |
| 10 | Seed demo data only when users table is empty and flag is on | Safe to restart; off for real use | Demo password is public, so flag must be off in production |
